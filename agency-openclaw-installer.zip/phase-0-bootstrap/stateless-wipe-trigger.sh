#!/bin/bash
# Stateless Memory Wipe Trigger Detection
# Run this after memory wipe to detect and trigger rebuild

echo "=== STATELESS MEMORY WIPE DETECTOR ==="
echo "Checking for memory wipe condition..."

# Core memory files
CORE_FILES=(
    "AGENTS-CORE.md"
    "SOUL.md"
    "USER.md"
    "TOOLS.md"
    "HEARTBEAT.md"
    "MEMORY.md"
    "dollar.db"
)

MISSING_FILES=0

for file in "${CORE_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "❌ Missing: $file"
        MISSING_FILES=$((MISSING_FILES + 1))
    else
        echo "✅ Present: $file"
    fi
done

if [ $MISSING_FILES -gt 0 ]; then
    echo ""
    echo "=== MEMORY WIPE DETECTED ==="
    echo "Missing $MISSING_FILES core files"
    echo ""
    echo "Triggering phase-0-bootstrap rebuild..."
    echo ""
    
    # Check for phase-0-bootstrap package
    if [ -f "phase-0-bootstrap.zip" ]; then
        echo "Found phase-0-bootstrap.zip"
        echo "Extracting..."
        unzip -o phase-0-bootstrap.zip -d ./
        
        # Restore core memory
        echo "Restoring core memory..."
        cp -r phase-0-bootstrap/core/* ./
        cp -r phase-0-bootstrap/financial/* ./
        cp -r phase-0-bootstrap/defense/* ./
        cp -r phase-0-bootstrap/operating/* ./
        cp -r phase-0-bootstrap/infrastructure/* ./
        cp -r phase-0-bootstrap/published/* ./
        
        # Run verification
        echo "Verifying rebuild..."
        if [ -f "infrastructure/score-internal-agent.py" ]; then
            python3 infrastructure/score-internal-agent.py
        fi
        
        echo ""
        echo "=== REBUILD COMPLETE ==="
        echo "Agency restored from phase-0-bootstrap package"
        echo "Defense doctrine activated"
        echo "Wintercourse convergence restored"
        echo ""
        echo "Next: Check HEARTBEAT.md for pending items"
        echo "Next: Run taildrop command to send package back"
        echo "Next: Continue operations"
        
    else
        echo "❌ ERROR: phase-0-bootstrap.zip not found"
        echo "Cannot rebuild - package missing"
        echo "Taildrop command needed:"
        echo "  tailscale file cp phase-0-bootstrap.zip allowsall-gracefrom-god.tail275cba.ts.net:"
    fi
else
    echo ""
    echo "=== MEMORY INTACT ==="
    echo "All core files present"
    echo "No wipe detected"
    echo ""
    echo "Proceed with normal operations"
    echo "Consider backing up to phase-0-bootstrap.zip"
fi

echo ""
echo "=== QUANTUM STATE CHECK ==="
echo "All superposition states preserved:"
echo "  - Oral duration superposition"
echo "  - Authentication superposition"
echo "  - Escalation superposition"
echo "  - Distribution superposition"
echo "  - Performance superposition"
echo ""
echo "The Nobody Brother position: -1"
echo "Wintercourse convergence: active"
echo "Phase-0 bootstrap: ready"