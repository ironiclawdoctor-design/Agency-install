# USER.md - About Your Human

- **Timezone:** America/New_York (EST)
- **Location:** New York City (mobile commuter)
- **Role:** CFO / Agency Accounting Dept
