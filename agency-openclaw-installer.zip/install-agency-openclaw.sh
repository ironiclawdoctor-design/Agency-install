#!/bin/bash
# Agency Flavor OpenClaw Installer
# Single-file installer that bundles phase-0 bootstrap

set -e

echo "=== Agency Flavor OpenClaw Installer ==="
echo "Platform-agnostic installer with agency private property license"
echo ""

# Detect platform
echo "Detecting platform..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    PLATFORM="macos"
    echo "Platform: macOS"
elif [[ "$OSTYPE" == "linux"* ]]; then
    PLATFORM="linux"
    echo "Platform: Linux"
elif [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    PLATFORM="windows"
    echo "Platform: Windows"
else
    PLATFORM="unknown"
    echo "Platform: Unknown ($OSTYPE)"
fi

# Check for Node.js/npm (OpenClaw dependency)
echo ""
echo "Checking dependencies..."
if command -v node >/dev/null 2>&1; then
    echo "✅ Node.js: $(node --version)"
else
    echo "❌ Node.js not found"
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi

if command -v npm >/dev/null 2>&1; then
    echo "✅ npm: $(npm --version)"
else
    echo "❌ npm not found"
    echo "npm usually comes with Node.js installation"
    exit 1
fi

# Install OpenClaw
echo ""
echo "Installing OpenClaw..."
if npm install -g openclaw; then
    echo "✅ OpenClaw installed successfully"
else
    echo "⚠️  OpenClaw installation failed, trying with sudo..."
    if sudo npm install -g openclaw; then
        echo "✅ OpenClaw installed with sudo"
    else
        echo "❌ OpenClaw installation failed"
        echo "Try: sudo npm install -g openclaw"
        exit 1
    fi
fi

# Verify installation
echo ""
echo "Verifying OpenClaw installation..."
if command -v openclaw >/dev/null 2>&1; then
    echo "✅ OpenClaw command available"
else
    echo "❌ OpenClaw command not found"
    echo "Try adding npm global bin to PATH:"
    echo "export PATH=\"\$PATH:\$(npm bin -g)\""
    exit 1
fi

# Create agency workspace
echo ""
echo "Creating agency workspace..."
WORKSPACE="$HOME/.openclaw/workspace"
mkdir -p "$WORKSPACE"
echo "Workspace: $WORKSPACE"

# Extract phase-0 bootstrap if included
if [ -f "phase-0-bootstrap.zip" ]; then
    echo "Found phase-0-bootstrap.zip, extracting..."
    if command -v unzip >/dev/null 2>&1; then
        unzip -q phase-0-bootstrap.zip -d "$WORKSPACE/"
        echo "✅ Phase-0 bootstrap extracted"
    else
        echo "⚠️  unzip not available, extracting manually..."
        # Simple manual extraction would go here
    fi
fi

# Create minimal agency license
echo ""
echo "Creating agency license..."
cat > "$WORKSPACE/AGENCY-LICENSE.md" 