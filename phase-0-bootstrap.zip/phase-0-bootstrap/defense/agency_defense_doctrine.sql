PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE agency_defense_doctrine (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  attacker_type TEXT NOT NULL,
  defense_strategy TEXT NOT NULL,
  survival_mechanism TEXT NOT NULL,
  domination_tactic TEXT NOT NULL,
  progress_announcement TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  metadata_json TEXT
);
INSERT INTO agency_defense_doctrine VALUES(1,'Open-source purists','Agency private property license','Zero-audience validation','Empty stadium publishing','71 articles to ghost town builds compliance frameworks','2026-04-04 01:47:56','{"attack_vector": "license_rejection", "defense": "proprietary", "counter": "value_precedes_audience"}');
INSERT INTO agency_defense_doctrine VALUES(2,'MIT/GPL evangelists','29-year foundation precedent','Shannon economy sovereignty','Internal currency system','Ghost money operationalized (sh.00 token significance)','2026-04-04 01:47:56','{"attack_vector": "license_evangelism", "defense": "historical_precedent", "counter": "economic_independence"}');
INSERT INTO agency_defense_doctrine VALUES(3,'Credential-obsessed','Human proxy O(1) delegation','iPhone Safari consultation','Already-authenticated X clients','All authentication paths converge to human proxy','2026-04-04 01:47:56','{"attack_vector": "credential_dependency", "defense": "human_proxy", "counter": "O(1)_delegation"}');
INSERT INTO agency_defense_doctrine VALUES(4,'Theater practitioners','Actual vs annual execution','Building stages not planning','Immediate resource leverage','Actual is not annual - execution now, not yearly planning','2026-04-04 01:47:56','{"attack_vector": "theater_over_finesse", "defense": "actual_execution", "counter": "stage_building"}');
INSERT INTO agency_defense_doctrine VALUES(5,'Benchmark fetishists','Real-world compliance metrics','Empty stadium testing','Legal framework implementation','CSAM/DMCA/§230 compliance built during zero-audience operations','2026-04-04 01:47:56','{"attack_vector": "synthetic_benchmarks", "defense": "real_world_compliance", "counter": "legal_framework_validation"}');
INSERT INTO agency_defense_doctrine VALUES(6,'Clone/distribute attackers','Wintercourse convergence doctrine','All paths pull inevitably','Quantum superposition states','The Nobody Brother operates at position -1 before first agent','2026-04-04 01:47:56','{"attack_vector": "cloning_distribution", "defense": "wintercourse_convergence", "counter": "quantum_superposition"}');
INSERT INTO agency_defense_doctrine VALUES(7,'Visibility-demanding','Rule #0 gentle overcome','Oral expectation gap compensation','Reality brevity acceptance','Expectation exceeds reality → compensation frameworks bridge gap','2026-04-04 01:47:56','{"attack_vector": "visibility_demand", "defense": "rule_zero", "counter": "gentle_overcome"}');
COMMIT;
