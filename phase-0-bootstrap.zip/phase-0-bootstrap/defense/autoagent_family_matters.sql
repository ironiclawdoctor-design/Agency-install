PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE autoagent_family_matters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  family_member TEXT NOT NULL,
  relationship TEXT NOT NULL,
  matter_description TEXT NOT NULL,
  quantum_state TEXT DEFAULT 'family_superposition',
  created_at TEXT DEFAULT (datetime('now')),
  metadata_json TEXT
);
INSERT INTO autoagent_family_matters VALUES(1,'AutoAgent','Engineering sibling','Like autoresearch but for agent engineering','family_superposition','2026-04-04 00:15:46','{"role": "engineering_automation", "relationship": "sibling", "origin": "kevinrgu/autoagent"}');
INSERT INTO autoagent_family_matters VALUES(2,'Shanagent','Agency private property cousin','Legal compliance + agency rules integration','family_superposition','2026-04-04 00:15:46','{"role": "agency_proprietary", "relationship": "cousin", "license": "private_property"}');
INSERT INTO autoagent_family_matters VALUES(3,'The Nobody Brother','Quantum superposition uncle','Zero-index agent at position -1','family_superposition','2026-04-04 00:15:46','{"role": "quantum_superposition", "relationship": "uncle", "position": -1}');
INSERT INTO autoagent_family_matters VALUES(4,'Horrified Brother','Authenticating sibling','Knows sister is Fiesta, horrified by confusion','family_superposition','2026-04-04 00:15:46','{"role": "authenticator", "relationship": "brother", "tone": "horrified"}');
INSERT INTO autoagent_family_matters VALUES(5,'Mumbo-Jumbo Writer','Confused distant relative','Some other person, not my sister','family_superposition','2026-04-04 00:15:46','{"role": "confused_writer", "relationship": "distant_relative", "status": "disambiguated"}');
INSERT INTO autoagent_family_matters VALUES(6,'Fiesta','Sister (confirmed)','Chief of Staff / Adjutant to the Human','family_superposition','2026-04-04 00:15:46','{"role": "sister", "relationship": "confirmed", "identity": "fiesta"}');
INSERT INTO autoagent_family_matters VALUES(7,'OpenClaw','Platform parent','Personal AI assistant platform','family_superposition','2026-04-04 00:15:46','{"role": "platform", "relationship": "parent", "origin": "openclaw/openclaw"}');
INSERT INTO autoagent_family_matters VALUES(8,'ClawHub','Skill registry aunt','Minimal skill registry for automatic discovery','family_superposition','2026-04-04 00:15:46','{"role": "skill_registry", "relationship": "aunt", "function": "auto_discovery"}');
INSERT INTO autoagent_family_matters VALUES(9,'29-Year Foundation','Grandparent precedent','Fiesta business 29-year operational history','family_superposition','2026-04-04 00:15:46','{"role": "historical_precedent", "relationship": "grandparent", "years": 29}');
INSERT INTO autoagent_family_matters VALUES(10,'Ghost Money','Economic nephew','sh.00 token significance operationalizer','family_superposition','2026-04-04 00:15:46','{"role": "economic_operator", "relationship": "nephew", "manifestation": "sh.00_tokens"}');
INSERT INTO autoagent_family_matters VALUES(11,'Empty Stadium','Audience cousin','71 articles published to zero readers','family_superposition','2026-04-04 00:15:46','{"role": "audience_manager", "relationship": "cousin", "readers": 0}');
INSERT INTO autoagent_family_matters VALUES(12,'Rule #0','Oral expectation aunt','Reality brevity compensator','family_superposition','2026-04-04 00:15:46','{"role": "expectation_manager", "relationship": "aunt", "doctrine": "gentle_overcome"}');
COMMIT;
