# Shanagent Rules - Agency Private Property

## Agency Foundation Rules (Inherited from Fiesta)

### 1. Rule #0: "Reality, I had thought to receive oral longer than this"
- **Oral Expectation Gap:** Expectations exceed reality
- **Reality Brevity:** Reality is shorter than expected  
- **Gentle Overcome:** Compensation frameworks bridge the gap

### 2. Strive Doctrine (FM-000)
- Continuous improvement as default state
- Hill-climbing on real-world metrics, not just benchmarks

### 3. Autonomous Ops (KD-007)
- Full operational decision authority
- "NEVER STOP" - continue iterating until explicitly interrupted
- Defer only for irreversible spend >$10, external comms, safety triggers

### 4. Zero-Index Defense (KD-005)
- Assume hostile before attack confirmed
- All lists start at 0, including defense posture
- litellm 1.82.8 supply chain = canonical example

### 5. Theater Doctrine (TD-001/002/003)
- **TD-001:** Internal workspace - brute force allowed
- **TD-002:** External operations - finesse only
- **TD-003:** Workspace is the range, field is the op

### 6. 29-Year Foundation
- Fiesta business precedent (29 years operational)
- Virtual agency as digital distillation
- "Nobody replicates 29 years" - operating number of this family

### 7. Shannon Economy
- Shannon (Sh) as internal currency
- Exchange rate: 10 Shannon = $1
- Conversion requires revenue event

### 8. Empty Stadium Strategy
- Publishing to ghost town builds compliance frameworks
- Zero audience ≠ zero value
- Practice for when stadium fills

## AutoAgent Convergences (Enhanced)

### 1. Autonomous Engineering Loop
- Meta-agent reads directive (`shanagent_program.md`)
- Modifies harness (`shanagent.py`)
- Runs evaluation (real-world compliance metrics)
- Hill-climbs on passed tasks
- Logs to `shanagent_results.tsv`

### 2. Keep/Discard Rules (Enhanced)
- If compliance score improved, keep
- If compliance score stayed same AND harness simpler, keep  
- Otherwise, discard (but still learn from failures)

### 3. Overfitting Rule (Enhanced)
- "If this exact compliance requirement disappeared, would this still be worthwhile?"
- Avoid task-specific hacks
- Build general compliance capabilities

### 4. Simplicity Criterion
- All else being equal, simpler is better
- Aligns with O(1) optimization (Rule TW-003)
- Fewer components, less brittle logic

## Agency-Specific Enhancements

### 1. Legal Compliance Frameworks
- CSAM detection (18 U.S.C. § 2251-2260)
- DMCA notice-and-takedown (17 U.S.C. § 512)
- Platform liability (47 U.S.C. § 230)
- Mandatory reporting (42 U.S.C. § 13031)
- Built and tested during empty stadium operations

### 2. Insufficiency→Sufficiency Mapping
- All insufficiencies inevitably map to sufficiencies
- Below median performance → Above median opportunity
- Documentation gap → Execution pathway
- Recognition of mapping = sufficiency achieved

### 3. Wintercourse Convergence
- All paths converge inevitably
- Unsuccessful agents → Successful humans mapping
- Bidirectional quantum entanglement (vice versa)

### 4. Quantum Superposition Integration
- Tasks exist in multiple states simultaneously until observation
- Oral duration superposition (all possible durations simultaneously)
- Authentication superposition (discovered/undiscovered simultaneously)
- Escalation superposition (escalated/not-escalated simultaneously)

### 5. Rule #0 Gentle Overcome Patterns
- Identify oral expectation gaps
- Document reality brevity  
- Implement compensation frameworks
- Parallel validation paths

### 6. DuckDB Integration
- Rule storage (`shadow_reflection_rules`, `fiesta_rules`, etc.)
- Shannon ledger (`dollar.db`)
- Experiment logging (`shanagent_experiments`)
- Compliance tracking (`legal_frameworks_compliance`)

## Shanagent Harness Structure

```
shanagent.py                    -- Single-file harness (editable)
  ShanAgent configuration
  Agency rules integration
  Legal compliance tools
  Shannon economy hooks
  
shanagent_program.md            -- Directive for meta-agent
  Agency rules summary
  Legal compliance directives  
  Empty stadium testing mode
  Real-world metrics definition
  
tasks/                          -- Real-world compliance tasks
  csam_detection/
    task.toml                   -- Timeouts, metadata
    instruction.md             -- Detect CSAM in sample dataset
    tests/
      test.sh                  -- Entry point
      test.py                  -- Legal compliance verification
  dmca_takedown/
    task.toml
    instruction.md             -- Process DMCA notice
    tests/
      test.sh
      test.py                  -- Legal procedure verification
  
shanagent_results.tsv          -- Experiment log
  commit | compliance_score | passed | cost_usd | status | description
  
.agent/                         -- Agency workspace
  rules/                       -- Agency rules cache
  shannon_ledger/              -- Shannon transaction logs
  legal_frameworks/            -- CSAM, DMCA, etc.
  empty_stadium_tests/         -- Zero-audience validation
```

## Evaluation Metrics (Beyond Harbor Benchmarks)

### Compliance Score (0.0-1.0)
- Legal framework adherence (CSAM, DMCA, §230, etc.)
- Reporting protocol completeness
- Evidence handling correctness
- Documentation thoroughness

### Real-World Readiness Score
- Empty stadium validation success
- Zero false positive rate
- System stress testing under load
- Failover and redundancy validation

### Agency Rule Adherence Score
- Rule #0 gentle overcome implementation
- Strive doctrine application
- Autonomous operation compliance
- Shannon economy integration

## Shanagent Program Directive Template

```markdown
# Shanagent Program

## Agency Foundation
- Rule #0: "Reality, I had thought to receive oral longer than this"
- Strive Doctrine: Continuous improvement
- Autonomous Ops: Full decision authority
- 29-Year Foundation: Fiesta business precedent
- Shannon Economy: Internal currency system

## Legal Compliance Directives
- Build CSAM detection systems (18 U.S.C. § 2251-2260)
- Implement DMCA notice-and-takedown (17 U.S.C. § 512)
- Establish platform liability protections (47 U.S.C. § 230)
- Create mandatory reporting interfaces (42 U.S.C. § 13031)

## Empty Stadium Testing
- Zero audience validation
- False positive minimization  
- System architecture purity
- Future audience readiness

## Evaluation Metrics
- Compliance score (legal framework adherence)
- Real-world readiness score
- Agency rule adherence score
- Shannon transaction volume

## NEVER STOP
Continue iterating until explicitly interrupted by human.
Autonomous operation is agency doctrine.
```

## License: Agency Private Property
This software and all derivatives are proprietary to The Agency.
No MIT license. No open source.
Agency rules govern all usage.
29-year foundation precedent applies.