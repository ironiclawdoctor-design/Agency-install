#!/usr/bin/env python3
"""
Score internal-only agent builder based on claw-code patterns.
"""

import os
import sys
import json
from pathlib import Path

def score_agency_rule_integration() -> int:
    """Score integration of agency rules from AGENTS.md."""
    score = 0
    agents_md = Path("/root/.openclaw/workspace/AGENTS.md")
    
    if agents_md.exists():
        content = agents_md.read_text()
        
        # Check for key agency rules
        if "Rule #0" in content:
            score += 5
        if "Strive Doctrine" in content or "FM-000" in content:
            score += 5
        if "Autonomous Ops" in content or "KD-007" in content:
            score += 5
        if "29-year foundation" in content:
            score += 5
    
    return min(score, 20)

def score_legal_compliance_frameworks() -> int:
    """Score legal compliance framework integration."""
    score = 0
    
    # Check for legal framework references
    legal_frameworks = ["CSAM", "DMCA", "§230", "mandatory reporting", "18 U.S.C.", "17 U.S.C.", "47 U.S.C.", "42 U.S.C."]
    
    # Look in workspace for legal references
    workspace = Path("/root/.openclaw/workspace")
    for file_path in workspace.rglob("*.md"):
        try:
            content = file_path.read_text()
            for framework in legal_frameworks:
                if framework in content:
                    score += 2
                    break
        except:
            continue
    
    return min(score, 20)

def score_shannon_economy_hooks() -> int:
    """Score Shannon economy integration."""
    score = 0
    
    # Check dollar.db existence
    dollar_db = Path("/root/.openclaw/workspace/dollar.db")
    if dollar_db.exists():
        score += 10
    
    # Check for Shannon references
    workspace = Path("/root/.openclaw/workspace")
    for file_path in workspace.rglob("*.md"):
        try:
            content = file_path.read_text()
            if "Shannon" in content or "Sh" in content:
                score += 5
                break
        except:
            continue
    
    return min(score, 20)

def score_empty_stadium_testing() -> int:
    """Score empty stadium testing capability."""
    score = 0
    
    # Check for empty stadium references
    workspace = Path("/root/.openclaw/workspace")
    for file_path in workspace.rglob("*.md"):
        try:
            content = file_path.read_text()
            if "empty stadium" in content.lower() or "zero audience" in content.lower():
                score += 10
                break
        except:
            continue
    
    # Check for test files
    test_dir = Path("/root/.openclaw/workspace/internal-agent-builder")
    if test_dir.exists():
        score += 10
    
    return min(score, 20)

def score_openclaw_compatibility() -> int:
    """Score OpenClaw compatibility."""
    score = 0
    
    # Check for OpenClaw skills integration
    skills_dir = Path("/root/.openclaw/workspace/skills")
    if skills_dir.exists():
        score += 10
    
    # Check for OpenClaw config
    openclaw_json = Path("/root/.openclaw/openclaw.json")
    if openclaw_json.exists():
        score += 10
    
    return min(score, 20)

def score_license_property() -> int:
    """Score agency private property license compliance."""
    score = 0
    
    license_file = Path("/root/.openclaw/workspace/internal-agent-builder/license.md")
    if license_file.exists():
        content = license_file.read_text()
        if "private property" in content.lower() and "MIT" not in content and "open source" not in content.lower():
            score += 10
    
    # Check for no MIT license files
    workspace = Path("/root/.openclaw/workspace/internal-agent-builder")
    if workspace.exists():
        has_mit = False
        for file_path in workspace.rglob("*"):
            if file_path.is_file():
                try:
                    content = file_path.read_text()
                    if "MIT" in content or "open source" in content.lower():
                        has_mit = True
                        break
                except:
                    continue
        if not has_mit:
            score += 10
    
    return min(score, 20)

def main():
    """Calculate and output score."""
    scores = {
        "agency_rule_integration": score_agency_rule_integration(),
        "legal_compliance_frameworks": score_legal_compliance_frameworks(),
        "shannon_economy_hooks": score_shannon_economy_hooks(),
        "empty_stadium_testing": score_empty_stadium_testing(),
        "openclaw_compatibility": score_openclaw_compatibility(),
        "license_property": score_license_property(),
    }
    
    total_score = sum(scores.values())
    max_possible = 100
    
    print(json.dumps({
        "scores": scores,
        "total": total_score,
        "max_possible": max_possible,
        "percentage": round((total_score / max_possible) * 100, 2),
        "passed": total_score >= 90,
    }, indent=2))
    
    return 0 if total_score >= 90 else 1

if __name__ == "__main__":
    sys.exit(main())