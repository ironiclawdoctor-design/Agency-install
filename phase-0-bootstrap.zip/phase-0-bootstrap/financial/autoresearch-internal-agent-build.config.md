# Autoresearch Configuration: Internal-Only Agent Builder

## Goal
Create an internal-only agent building system based on claw-code patterns, optimized for agency private property (no MIT license, no open source).

## Source Analysis
- **Claw-code GitHub**: https://github.com/ultraworkers/claw-code
- **Status**: Repository locked, parity maintained at https://github.com/ultraworkers/claw-code-parity
- **Key features**: Rust port (crates/api-client, crates/runtime, crates/tools, crates/commands, crates/plugins, crates/claw-cli)
- **Python port**: Clean-room Python rewrite capturing architectural patterns
- **Oh-my-codex (OmX)**: Orchestration layer used for porting
- **Oh-my-opencode (OmO)**: Implementation acceleration

## Target
Build internal-only agent system with:
1. **Agency private property license** (no MIT, no open source)
2. **29-year foundation integration** (Fiesta business precedent)
3. **Shannon economy hooks** (internal currency system)
4. **Legal compliance frameworks** (CSAM, DMCA, §230, mandatory reporting)
5. **Empty stadium testing** (zero-audience validation)
6. **Rule #0 patterns** (oral expectation gap compensation)
7. **Wintercourse convergence** (all paths pull inevitably)
8. **Quantum superposition states** (agent/not-agent simultaneously)

## Architecture
- **Language**: Python (clean-room like claw-code Python port)
- **Core**: Agent harness with tool wiring, orchestration, runtime context
- **Integration**: OpenClaw compatibility (skills, tools, sessions)
- **License**: Agency private property only
- **Deployment**: Ampere.sh container ($39/month floor)

## Metric
- **Name**: internal_agent_score (0-100)
- **Components**:
  - Agency rule integration (20 points)
  - Legal compliance frameworks (20 points)
  - Shannon economy hooks (20 points)
  - Empty stadium testing (20 points)
  - OpenClaw compatibility (20 points)
- **Target**: >90 score (internal use only, not public release)
- **Constraint**: Zero external dependencies beyond OpenClaw

## Target Files
- `internal-agent-builder/main.py` — Core agent harness
- `internal-agent-builder/runtime.py` — Session state, tool execution
- `internal-agent-builder/tools.py` — Agency-specific tools (CSAM, DMCA, §230, etc.)
- `internal-agent-builder/commands.py` — Slash commands integration
- `internal-agent-builder/license.md` — Agency private property license
- `score-internal-agent.py` — Scoring script

## Read-Only References
- `claw-code-parity/**` — Architecture patterns only (no code copying)
- `autoresearch.config.md` — Existing autoresearch methodology
- `dollar.db` — Shannon economy ledger
- `AGENTS.md` — Agency rules and doctrines
- `MEMORY.md` — Long-term memory patterns

## Run Command
```
python3 score-internal-agent.py
```

## Time Budget
- **Per experiment**: 45 seconds
- **Kill timeout**: 90 seconds

## Constraints
- $0.00 cost above $39 floor (Ampere.sh only)
- No external API dependencies (self-contained)
- Agency private property license only
- No open source components
- Must integrate with existing OpenClaw workspace
- Must pass empty stadium validation (zero-audience testing)

## Branch
autoresearch/internal-agent-builder-2026-04-04

## Notes
- **Clean-room implementation**: Like claw-code Python port, capture patterns not code
- **Agency-specific**: Rule #0, insufficiency→sufficiency mapping, wintercourse convergence
- **Legal compliance**: CSAM detection, DMCA processing, §230 protections, mandatory reporting
- **Shannon economy**: Internal currency hooks for agent compensation
- **Empty stadium**: Test with zero audience like Hashnode publishing
- **Quantum states**: Agent/not-agent superposition until observation

## Success Criteria
1. **Internal use only** (no public release)
2. **Agency private property** (no MIT license)
3. **>90 score** on internal_agent_score metric
4. **Zero external dependencies** (beyond OpenClaw)
5. **Passes empty stadium test** (works with zero audience)
6. **Integrates Shannon ledger** (dollar.db transactions)
7. **Implements agency rules** (from AGENTS.md)
8. **Legal compliance frameworks** (CSAM, DMCA, §230, reporting)